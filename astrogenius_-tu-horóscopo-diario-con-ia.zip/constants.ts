
import { ZodiacSign } from './types';

export const ZODIAC_SIGNS: ZodiacSign[] = [
    { name: 'Aries', range: 'Mar 21 - Abr 19', icon: '♈' },
    { name: 'Tauro', range: 'Abr 20 - May 20', icon: '♉' },
    { name: 'Géminis', range: 'May 21 - Jun 20', icon: '♊' },
    { name: 'Cáncer', range: 'Jun 21 - Jul 22', icon: '♋' },
    { name: 'Leo', range: 'Jul 23 - Ago 22', icon: '♌' },
    { name: 'Virgo', range: 'Ago 23 - Sep 22', icon: '♍' },
    { name: 'Libra', range: 'Sep 23 - Oct 22', icon: '♎' },
    { name: 'Escorpio', range: 'Oct 23 - Nov 21', icon: '♏' },
    { name: 'Sagitario', range: 'Nov 22 - Dic 21', icon: '♐' },
    { name: 'Capricornio', range: 'Dic 22 - Ene 19', icon: '♑' },
    { name: 'Acuario', range: 'Ene 20 - Feb 18', icon: '♒' },
    { name: 'Piscis', range: 'Feb 19 - Mar 20', icon: '♓' }
];

export const getZodiacSign = (date: Date): ZodiacSign | null => {
    if (isNaN(date.getTime())) return null;
    const day = date.getDate();
    const month = date.getMonth() + 1;

    if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return ZODIAC_SIGNS[0];
    if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return ZODIAC_SIGNS[1];
    if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return ZODIAC_SIGNS[2];
    if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return ZODIAC_SIGNS[3];
    if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return ZODIAC_SIGNS[4];
    if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return ZODIAC_SIGNS[5];
    if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return ZODIAC_SIGNS[6];
    if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return ZODIAC_SIGNS[7];
    if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return ZODIAC_SIGNS[8];
    if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return ZODIAC_SIGNS[9];
    if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return ZODIAC_SIGNS[10];
    if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return ZODIAC_SIGNS[11];
    return null;
};
