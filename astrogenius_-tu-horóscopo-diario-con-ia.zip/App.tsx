import React, { useState, useCallback, useMemo } from 'react';
import { ZodiacSign, HoroscopeData, View } from './types';
import { getZodiacSign, ZODIAC_SIGNS } from './constants';
import { getHoroscope } from './services/geminiService';
import Header from './components/Header';
import Footer from './components/Footer';
import ZodiacSelector from './components/ZodiacSelector';
import HoroscopeDisplay from './components/HoroscopeDisplay';
import Loader from './components/Loader';
import Particles from './components/Particles';
import AboutSection from './components/AboutSection';
import FAQSection from './components/FAQSection';
import CompatibilitySection from './components/CompatibilitySection';
import BlogSection from './components/BlogSection';
import AstralChartSection from './components/AstralChartSection';
import NewsSection from './components/NewsSection';
import PredictiveReadingsSection from './components/PredictiveReadingsSection';
import KarmicAstrologySection from './components/KarmicAstrologySection';
import RelationshipAstrologySection from './components/RelationshipAstrologySection';
import ElectiveAstrologySection from './components/ElectiveAstrologySection';

const App: React.FC = () => {
    const [birthDate, setBirthDate] = useState<string>('');
    const [zodiacSign, setZodiacSign] = useState<ZodiacSign | null>(null);
    const [horoscope, setHoroscope] = useState<HoroscopeData | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [view, setView] = useState<View>('horoscope');

    const handleDateChange = (date: string) => {
        setBirthDate(date);
        const sign = getZodiacSign(new Date(date + 'T00:00:00')); // Use T00:00:00 to avoid timezone issues
        setZodiacSign(sign);
        setHoroscope(null);
        setError(null);
    };

    const fetchHoroscope = useCallback(async () => {
        if (!zodiacSign) return;
        setIsLoading(true);
        setError(null);
        setHoroscope(null);

        try {
            const data = await getHoroscope(zodiacSign.name);
            setHoroscope(data);
        } catch (err) {
            console.error("Error fetching horoscope:", err);
            setError('No se pudo generar tu horóscopo. Por favor, intenta de nuevo más tarde.');
        } finally {
            setIsLoading(false);
        }
    }, [zodiacSign]);

    const renderView = () => {
        switch (view) {
            case 'horoscope':
                return (
                    <>
                        <ZodiacSelector
                            birthDate={birthDate}
                            onDateChange={handleDateChange}
                            zodiacSign={zodiacSign}
                            onGenerate={fetchHoroscope}
                            isLoading={isLoading}
                        />
                        {isLoading && <Loader />}
                        {error && <p className="text-center text-red-400 mt-4 animate-fade-in">{error}</p>}
                        {horoscope && (
                            <>
                                <HoroscopeDisplay horoscope={horoscope} zodiacSign={zodiacSign} />
                                <NewsSection />
                            </>
                        )}
                    </>
                );
            case 'about':
                return <AboutSection />;
            case 'faq':
                return <FAQSection />;
            case 'compatibility':
                return <CompatibilitySection />;
            case 'blog':
                return <BlogSection />;
            case 'astral_chart':
                return <AstralChartSection />;
            case 'predictive':
                return <PredictiveReadingsSection />;
            case 'karmic':
                return <KarmicAstrologySection />;
            case 'relationships':
                return <RelationshipAstrologySection />;
            case 'elective':
                return <ElectiveAstrologySection />;
            default:
                return null;
        }
    };

    return (
        <div className="relative min-h-screen bg-gradient-to-br from-[#0c0a1a] via-[#1f1a3a] to-[#3a2f6b] text-white font-sans overflow-x-hidden">
            <Particles />
            <div className="relative z-10">
                <Header setView={setView} currentView={view}/>
                <main className="container mx-auto px-4 py-8 md:py-16">
                    {/* AdSense Header Placeholder */}
                    <div className="mb-8 h-24 bg-white/5 rounded-lg flex items-center justify-center text-gray-400 text-sm">
                        Espacio para Anuncio (Header)
                    </div>
                    {renderView()}
                </main>
                <Footer />
            </div>
        </div>
    );
};

export default App;