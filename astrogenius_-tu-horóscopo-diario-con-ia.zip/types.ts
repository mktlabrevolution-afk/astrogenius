export interface ZodiacSign {
    name: string;
    range: string;
    icon: string;
}

export interface HoroscopeData {
    amor: string;
    trabajo: string;
    salud: string;
    finanzas: string;
    consejo: string;
    numerosSuerte: number[];
    colorSuerte: string;
}

export interface AstralChartData {
    sunSign: string;
    sunInterpretation: string;
    moonSign: string;
    moonInterpretation: string;
    ascendantSign: string;
    ascendantInterpretation: string;
    summary: string;
    keyPlanets: {
        planet: string;
        sign: string;
        interpretation: string;
    }[];
}

export interface SolarReturnData {
    themeOfYear: string;
    keyAreas: {
        area: string;
        focus: string;
    }[];
    advice: string;
}

export interface TransitData {
    overview: string;
    keyTransits: {
        date: string;
        planet: string;
        aspect: string;
        influence: string;
    }[];
}

export interface KarmicAstrologyData {
    reportTitle: string;
    essay: string;
}

export interface PsychoAstrologyData {
    moonAnalysis: {
        title: string;
        analysis: string;
    };
    chironAnalysis: {
        title: string;
        analysis: string;
    };
}

export interface SynastryData {
    title: string;
    summary: string;
    strengths: { aspect: string; interpretation: string }[];
    challenges: { aspect: string; interpretation: string }[];
}

export interface CompositeChartData {
    title: string;
    purpose: string;
    keyThemes: { theme: string; interpretation: string }[];
}

export interface ElectiveAstrologyData {
    recommendations: {
        date: string;
        time: string;
        justification: string;
    }[];
}

export interface AstrocartographyData {
    interpretation: string;
    mapImage: string; // base64 encoded image
}


export interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}

export interface NewsArticle {
  title: string;
  summary: string;
}

export type View = 'horoscope' | 'about' | 'faq' | 'compatibility' | 'blog' | 'astral_chart' | 'predictive' | 'karmic' | 'relationships' | 'elective';