import { GoogleGenAI, Type, Modality } from "@google/genai";
import { HoroscopeData, AstralChartData, GroundingChunk, SolarReturnData, TransitData, KarmicAstrologyData, PsychoAstrologyData, SynastryData, CompositeChartData, ElectiveAstrologyData, AstrocartographyData } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const horoscopeSchema = {
    type: Type.OBJECT,
    properties: {
        amor: { type: Type.STRING, description: 'Predicción de amor en 2-3 frases.' },
        trabajo: { type: Type.STRING, description: 'Predicción de trabajo en 2-3 frases.' },
        salud: { type: Type.STRING, description: 'Predicción de salud en 2-3 frases.' },
        finanzas: { type: Type.STRING, description: 'Predicción de finanzas en 2-3 frases.' },
        consejo: { type: Type.STRING, description: 'Un consejo inspirador en 1-2 frases.' },
        numerosSuerte: { 
            type: Type.ARRAY,
            items: { type: Type.NUMBER },
            description: 'Un array de 3 números de la suerte.'
        },
        colorSuerte: { type: Type.STRING, description: 'Un color favorable para el día.' }
    },
    required: ['amor', 'trabajo', 'salud', 'finanzas', 'consejo', 'numerosSuerte', 'colorSuerte']
};

export const getHoroscope = async (signName: string): Promise<HoroscopeData> => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const cacheKey = `horoscope_${signName}_${today}`;
    const cachedData = localStorage.getItem(cacheKey);

    if (cachedData) {
        console.log("Serving horoscope from cache");
        return JSON.parse(cachedData) as HoroscopeData;
    }

    console.log("Fetching horoscope from API");
    const prompt = `Genera un horóscopo diario realista y positivo para ${signName} para hoy, ${new Date().toLocaleDateString('es-ES')}. Tono: profesional, optimista pero realista, evita clichés. Sé conciso y directo.`;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: horoscopeSchema,
                temperature: 0.8,
                topP: 0.9,
            },
        });
        
        const text = response.text.trim();
        const data: HoroscopeData = JSON.parse(text);

        localStorage.setItem(cacheKey, JSON.stringify(data));
        return data;
    } catch (error) {
        console.error('Error calling Gemini API:', error);
        throw new Error('Failed to generate horoscope from API.');
    }
};

const astralChartSchema = {
    type: Type.OBJECT,
    properties: {
        sunSign: { type: Type.STRING, description: "El signo solar del individuo." },
        sunInterpretation: { type: Type.STRING, description: "Interpretación del signo solar (2-3 frases sobre la identidad central)." },
        moonSign: { type: Type.STRING, description: "El signo lunar del individuo." },
        moonInterpretation: { type: Type.STRING, description: "Interpretación del signo lunar (2-3 frases sobre el mundo emocional)." },
        ascendantSign: { type: Type.STRING, description: "El signo ascendente del individuo." },
        ascendantInterpretation: { type: Type.STRING, description: "Interpretación del signo ascendente (2-3 frases sobre cómo se presenta al mundo)." },
        summary: { type: Type.STRING, description: "Un resumen general de la carta astral y sus temas principales en 3-4 frases." },
        keyPlanets: {
            type: Type.ARRAY,
            description: "Interpretación de los 3 planetas personales clave: Mercurio, Venus y Marte.",
            items: {
                type: Type.OBJECT,
                properties: {
                    planet: { type: Type.STRING, description: "Nombre del planeta (e.g., 'Mercurio')." },
                    sign: { type: Type.STRING, description: "Signo en el que se encuentra el planeta." },
                    interpretation: { type: Type.STRING, description: "Breve interpretación de la posición del planeta (1-2 frases)." }
                },
                required: ['planet', 'sign', 'interpretation']
            }
        }
    },
    required: ['sunSign', 'sunInterpretation', 'moonSign', 'moonInterpretation', 'ascendantSign', 'ascendantInterpretation', 'summary', 'keyPlanets']
};

export const getAstralChart = async (birthDate: string, birthTime: string, birthPlace: string): Promise<AstralChartData> => {
    console.log("Generating Astral Chart from API");
    const prompt = `Actúa como un astrólogo experto, cálido y perspicaz. Basado en los siguientes datos de nacimiento, genera una interpretación de una carta astral. La interpretación debe ser profunda, positiva y fácil de entender para alguien sin conocimientos de astrología. No menciones los cálculos, solo el resultado interpretativo.

Datos de Nacimiento:
- Fecha: ${birthDate}
- Hora: ${birthTime}
- Lugar: ${birthPlace}

Genera un análisis que cubra los 'Tres Grandes' (Sol, Luna, Ascendente) y los planetas personales clave (Mercurio, Venus, Marte).`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: astralChartSchema,
                temperature: 0.7,
            },
        });

        const text = response.text.trim();
        const data: AstralChartData = JSON.parse(text);
        return data;
    } catch (error) {
        console.error('Error calling Gemini API for Astral Chart:', error);
        throw new Error('Failed to generate astral chart from API.');
    }
};

export const getAstrologyNews = async (): Promise<{ summaryText: string; sources: GroundingChunk[] | undefined }> => {
    const today = new Date().toISOString().split('T')[0];
    const cacheKey = `astrology_news_${today}`;
    const cachedData = localStorage.getItem(cacheKey);

    if (cachedData) {
        console.log("Serving news from cache");
        return JSON.parse(cachedData);
    }

    console.log("Fetching news from API");
    const prompt = `Busca y resume las 3 noticias de astrología más recientes y relevantes. Formatea la respuesta estrictamente de la siguiente manera, usando '|||' como separador entre noticias:\nTITULO: [título de la noticia]\nRESUMEN: [resumen de 2-3 frases]\n|||`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });

        const result = {
            summaryText: response.text,
            sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined,
        };

        localStorage.setItem(cacheKey, JSON.stringify(result));
        return result;

    } catch (error) {
        console.error('Error calling Gemini API for news:', error);
        throw new Error('Failed to generate news from API.');
    }
};

const solarReturnSchema = {
    type: Type.OBJECT,
    properties: {
        themeOfYear: { type: Type.STRING, description: "El tema principal y la energía del año personal del consultante, de cumpleaños a cumpleaños." },
        keyAreas: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    area: { type: Type.STRING, description: "Área de vida clave (ej. Amor, Carrera, Crecimiento Personal)." },
                    focus: { type: Type.STRING, description: "Explicación breve de qué esperar en esta área." }
                },
                required: ['area', 'focus']
            }
        },
        advice: { type: Type.STRING, description: "Un consejo práctico para aprovechar al máximo las energías del año." }
    },
    required: ['themeOfYear', 'keyAreas', 'advice']
};

export const getSolarReturn = async (birthDate: string): Promise<SolarReturnData> => {
    const prompt = `Calcula e interpreta el informe de Revolución Solar para una persona nacida el ${birthDate}. El informe debe ser para su próximo año personal (de su último cumpleaños a su próximo). Enfócate en los temas principales, las áreas de vida más activadas y ofrece un consejo clave. Tono: predictivo, orientador.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: solarReturnSchema, temperature: 0.7 }
    });
    return JSON.parse(response.text.trim());
};

const transitsSchema = {
    type: Type.OBJECT,
    properties: {
        overview: { type: Type.STRING, description: "Un resumen general del clima astrológico para los próximos 6 meses." },
        keyTransits: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "Fecha o rango de fechas clave del tránsito." },
                    planet: { type: Type.STRING, description: "Planeta en tránsito." },
                    aspect: { type: Type.STRING, description: "Aspecto que forma (ej. 'conjunción con Sol Natal')." },
                    influence: { type: Type.STRING, description: "Breve explicación de su influencia." }
                },
                required: ['date', 'planet', 'aspect', 'influence']
            }
        }
    },
    required: ['overview', 'keyTransits']
};

export const getTransits = async (birthDate: string, birthTime: string, birthPlace: string): Promise<TransitData> => {
    const prompt = `Analiza los tránsitos y progresiones más importantes para los próximos 6 meses para una persona con los siguientes datos de nacimiento: ${birthDate}, ${birthTime}, ${birthPlace}. Identifica 3-4 tránsitos clave, sus fechas y su impacto potencial. Tono: informativo, estratégico.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: transitsSchema, temperature: 0.7 }
    });
    return JSON.parse(response.text.trim());
};

const karmicAstrologySchema = {
    type: Type.OBJECT,
    properties: {
        reportTitle: { type: Type.STRING, description: "Un título atractivo para el informe, ya sea sobre los Nodos Lunares o el Retorno de Saturno, según corresponda a la edad del consultante." },
        essay: { type: Type.STRING, description: "Un ensayo profundo y revelador (3-4 párrafos) sobre el propósito de vida, lecciones kármicas y ciclos de madurez, centrado en los Nodos Lunares o el Retorno de Saturno si la persona está en la edad relevante (aprox. 27-30 años)." }
    },
    required: ['reportTitle', 'essay']
};

export const getKarmicAstrologyReport = async (birthDate: string, birthTime: string, birthPlace: string): Promise<KarmicAstrologyData> => {
    const prompt = `Actúa como un astrólogo kármico con una perspectiva psicológica profunda. Basado en los datos de nacimiento (${birthDate}, ${birthTime}, ${birthPlace}), genera un ensayo sobre el propósito del alma.
    - Analiza la posición de los Nodos Lunares (Norte y Sur) en la carta natal. Explica la lección kármica principal: de dónde viene (Nodo Sur) y hacia dónde se dirige su alma para crecer (Nodo Norte).
    - Si la persona tiene entre 27 y 31 años, enfoca el ensayo en la experiencia del Retorno de Saturno como un rito de paso hacia la madurez.
    - El tono debe ser empoderador, sabio y compasivo.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: karmicAstrologySchema, temperature: 0.75 }
    });
    return JSON.parse(response.text.trim());
};

const psychoAstrologySchema = {
    type: Type.OBJECT,
    properties: {
        moonAnalysis: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "Un título poético para el análisis de la Luna." },
                analysis: { type: Type.STRING, description: "Un análisis (2-3 párrafos) de la Luna en la carta, enfocándose en las necesidades emocionales, el inconsciente y los patrones de seguridad." }
            },
            required: ['title', 'analysis']
        },
        chironAnalysis: {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "Un título evocador para el análisis de Quirón." },
                analysis: { type: Type.STRING, description: "Un análisis (2-3 párrafos) de Quirón, describiendo la 'herida primaria' y cómo su integración puede convertirse en una fuente de sanación y sabiduría para uno mismo y para los demás." }
            },
            required: ['title', 'analysis']
        }
    },
    required: ['moonAnalysis', 'chironAnalysis']
};

export const getPsychoAstrologyReport = async (birthDate: string, birthTime: string, birthPlace: string): Promise<PsychoAstrologyData> => {
    const prompt = `Actúa como un astrólogo con una fuerte orientación psicológica y junguiana. Basado en los datos de nacimiento (${birthDate}, ${birthTime}, ${birthPlace}), realiza un análisis profundo de la psique.
    1.  **Análisis de la Luna**: Profundiza en la posición de la Luna (signo y casa) para revelar las necesidades emocionales subyacentes, el lenguaje del inconsciente del individuo y qué le proporciona verdadera seguridad y nutrición emocional.
    2.  **Análisis de Quirón**: Identifica la posición de Quirón como la 'herida sagrada'. Describe la naturaleza de esta herida existencial y, lo más importante, cómo el trabajo consciente con ella puede transformarse en el mayor don y fuente de sanación del individuo.
    El tono debe ser terapéutico, compasivo y revelador.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: psychoAstrologySchema, temperature: 0.75 }
    });
    return JSON.parse(response.text.trim());
};

const synastrySchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "Un título para el informe de sinastría (ej. 'La Danza Cósmica de [Nombre1] y [Nombre2]')." },
        summary: { type: Type.STRING, description: "Un resumen general (3-4 frases) de la dinámica de la relación, su energía principal y potencial." },
        strengths: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    aspect: { type: Type.STRING, description: "El aspecto armónico clave (ej. 'Sol de P1 en trígono a la Luna de P2')." },
                    interpretation: { type: Type.STRING, description: "Interpretación del aspecto (1-2 frases)." }
                }, required: ['aspect', 'interpretation']
            }
        },
        challenges: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    aspect: { type: Type.STRING, description: "El aspecto desafiante clave (ej. 'Venus de P1 en cuadratura a Marte de P2')." },
                    interpretation: { type: Type.STRING, description: "Interpretación del desafío y consejo para superarlo (1-2 frases)." }
                }, required: ['aspect', 'interpretation']
            }
        }
    }, required: ['title', 'summary', 'strengths', 'challenges']
};

export const getSynastryReport = async (person1Data: string, person2Data: string): Promise<SynastryData> => {
    const prompt = `Actúa como un astrólogo de relaciones. Compara estas dos cartas natales (sinastría) y genera un informe. Persona 1: ${person1Data}. Persona 2: ${person2Data}. Enfócate en 2-3 fortalezas y 2-3 desafíos clave. Sé claro y constructivo.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: synastrySchema, temperature: 0.7 }
    });
    return JSON.parse(response.text.trim());
};

const compositeChartSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "Un título para el informe de carta compuesta (ej. 'El Alma de la Relación')." },
        purpose: { type: Type.STRING, description: "El propósito y la misión principal de esta relación como una entidad propia (2-3 frases)." },
        keyThemes: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    theme: { type: Type.STRING, description: "El tema clave revelado por la carta compuesta (ej. 'Sol Compuesto en Casa 10')." },
                    interpretation: { type: Type.STRING, description: "Interpretación de cómo este tema se manifiesta en la relación (1-2 frases)." }
                }, required: ['theme', 'interpretation']
            }
        }
    }, required: ['title', 'purpose', 'keyThemes']
};

export const getCompositeChartReport = async (person1Data: string, person2Data: string): Promise<CompositeChartData> => {
    const prompt = `Actúa como un astrólogo de relaciones. Crea una carta compuesta a partir de los datos de estas dos personas y genera un informe. Persona 1: ${person1Data}. Persona 2: ${person2Data}. Enfócate en el propósito de la unión y 2-3 temas principales.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: compositeChartSchema, temperature: 0.7 }
    });
    return JSON.parse(response.text.trim());
};

const electiveAstrologySchema = {
    type: Type.OBJECT,
    properties: {
        recommendations: {
            type: Type.ARRAY,
            description: "Una lista de las mejores 3 fechas y horas para el evento.",
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "La fecha recomendada (YYYY-MM-DD)." },
                    time: { type: Type.STRING, description: "La hora o rango de horas recomendado (ej. '10:30 AM')." },
                    justification: { type: Type.STRING, description: "Una breve justificación astrológica de por qué este es un buen momento (1-2 frases)." }
                },
                required: ['date', 'time', 'justification']
            }
        }
    },
    required: ['recommendations']
};

export const getElectiveAstrologyReport = async (birthData: string, event: string, dateRange: string): Promise<ElectiveAstrologyData> => {
    const prompt = `Actúa como un astrólogo electivo experto. Para una persona con datos de nacimiento (${birthData}), que quiere realizar el siguiente evento: "${event}", recomienda las 3 mejores fechas y horas dentro del rango de fechas: ${dateRange}. Justifica cada elección astrológicamente. Tono: preciso, profesional, estratégico.`;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
        config: { responseMimeType: 'application/json', responseSchema: electiveAstrologySchema, temperature: 0.6 }
    });
    return JSON.parse(response.text.trim());
};

export const getAstrocartographyReport = async (birthData: string, goal: string): Promise<AstrocartographyData> => {
    const prompt = `Actúa como un astrocartógrafo. Para una persona nacida (${birthData}) con el objetivo de "${goal}", realiza dos tareas:
1.  **Informe de Texto**: Describe las 3 mejores ubicaciones geográficas en el mundo para esta persona, explicando qué líneas planetarias se activan allí (ej. Venus-AC, Júpiter-MC) y por qué son beneficiosas para su objetivo.
2.  **Mapa Visual**: Genera una imagen de un mapa del mundo estilizado y visualmente atractivo. El mapa debe mostrar las principales líneas planetarias (Venus, Júpiter, Sol, Luna) correspondientes a la carta natal del individuo. El estilo debe ser místico y elegante, con colores cósmicos.`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: prompt }] },
        config: {
            responseModalities: [Modality.IMAGE],
        },
    });

    let interpretation = "No se pudo generar la interpretación.";
    let mapImage = "";

    for (const part of response.candidates[0].content.parts) {
        if (part.text) {
            interpretation = part.text;
        } else if (part.inlineData) {
            mapImage = part.inlineData.data;
        }
    }

    if (!mapImage) {
        throw new Error("La API no generó una imagen del mapa.");
    }

    return { interpretation, mapImage };
};