import React, { useEffect, useState } from 'react';
import { getAstrologyNews } from '../services/geminiService';
import { NewsArticle, GroundingChunk } from '../types';

const NewsSkeleton: React.FC = () => (
    <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg animate-pulse">
        <div className="w-3/4 h-6 mb-4 bg-white/10 rounded"></div>
        <div className="space-y-2">
            <div className="w-full h-4 bg-white/10 rounded"></div>
            <div className="w-5/6 h-4 bg-white/10 rounded"></div>
        </div>
        <div className="w-1/4 h-4 mt-4 bg-white/10 rounded"></div>
    </div>
);

const NewsSection: React.FC = () => {
    const [articles, setArticles] = useState<NewsArticle[]>([]);
    const [sources, setSources] = useState<GroundingChunk[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchNews = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const { summaryText, sources } = await getAstrologyNews();

                const parsedArticles: NewsArticle[] = summaryText
                    .split('|||')
                    .map(entry => {
                        const titleMatch = entry.match(/TITULO: (.*)/);
                        const summaryMatch = entry.match(/RESUMEN: (.*)/s);
                        if (titleMatch && summaryMatch) {
                            return {
                                title: titleMatch[1].trim(),
                                summary: summaryMatch[1].trim(),
                            };
                        }
                        return null;
                    })
                    .filter((article): article is NewsArticle => article !== null);

                setArticles(parsedArticles);
                setSources(sources || []);
            } catch (err) {
                console.error("Error fetching news:", err);
                setError('No se pudieron cargar las noticias astrológicas.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchNews();
    }, []);

    if (isLoading) {
        return (
            <div className="mt-16">
                <h2 className="text-center text-3xl font-bold mb-8 animate-fade-in">Noticias Astrológicas</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <NewsSkeleton />
                    <NewsSkeleton />
                    <NewsSkeleton />
                </div>
            </div>
        );
    }

    if (error) {
        return <p className="text-center text-red-400 mt-8">{error}</p>;
    }

    if (articles.length === 0) {
        return null; // Don't render the section if there are no articles
    }

    return (
        <div className="mt-16 animate-fade-in-up">
            <h2 className="text-center text-3xl font-bold mb-8">
                Noticias <span className="text-purple-400">Astrológicas</span>
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {articles.map((article, index) => (
                    <div key={index} className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg transform hover:-translate-y-2 transition-all duration-300 flex flex-col">
                        <h3 className="text-xl font-semibold text-purple-300 mb-3">{article.title}</h3>
                        <p className="text-gray-300 text-sm leading-relaxed flex-grow">{article.summary}</p>
                    </div>
                ))}
            </div>
            {sources.length > 0 && (
                <div className="text-center mt-8">
                    <h4 className="text-lg font-semibold text-purple-300 mb-3">Fuentes</h4>
                    <div className="flex flex-wrap justify-center gap-x-4 gap-y-2">
                        {sources.map((source, index) => (
                            <a
                                key={index}
                                href={source.web.uri}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-sm text-pink-400 hover:text-pink-300 transition-colors underline"
                            >
                                {source.web.title || new URL(source.web.uri).hostname}
                            </a>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default NewsSection;