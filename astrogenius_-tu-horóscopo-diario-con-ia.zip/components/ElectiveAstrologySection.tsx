import React, { useState } from 'react';
import { getElectiveAstrologyReport, getAstrocartographyReport } from '../services/geminiService';
import { ElectiveAstrologyData, AstrocartographyData } from '../types';
import ReportGeneratorCard from './ReportGeneratorCard';
import Loader from './Loader';

const ElectiveAstrologySection: React.FC = () => {
    const [formData, setFormData] = useState({ date: '', time: '', place: '' });
    const [isDataSubmitted, setIsDataSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    // Elective Astrology State
    const [electiveFormData, setElectiveFormData] = useState({ event: '', startDate: '', endDate: '' });
    const [electiveReport, setElectiveReport] = useState<ElectiveAstrologyData | null>(null);
    const [isElectiveLoading, setIsElectiveLoading] = useState(false);
    const [electiveError, setElectiveError] = useState<string | null>(null);

    // Astrocartography State
    const [astrocartographyGoal, setAstrocartographyGoal] = useState('');
    const [astrocartographyReport, setAstrocartographyReport] = useState<AstrocartographyData | null>(null);
    const [isAstrocartographyLoading, setIsAstrocartographyLoading] = useState(false);
    const [astrocartographyError, setAstrocartographyError] = useState<string | null>(null);

    const handleMainFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleMainFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            setIsDataSubmitted(true);
            setIsLoading(false);
        }, 500);
    };

    const handleGetElectiveReport = async () => {
        if (!electiveFormData.event || !electiveFormData.startDate || !electiveFormData.endDate) {
            setElectiveError("Por favor, completa todos los campos del evento.");
            return;
        }
        setIsElectiveLoading(true); setElectiveError(null); setElectiveReport(null);
        try {
            const birthData = `Fecha: ${formData.date}, Hora: ${formData.time}, Lugar: ${formData.place}`;
            const dateRange = `de ${electiveFormData.startDate} a ${electiveFormData.endDate}`;
            const data = await getElectiveAstrologyReport(birthData, electiveFormData.event, dateRange);
            setElectiveReport(data);
        } catch (err) { setElectiveError('No se pudo generar el informe de astrología electiva.'); }
        finally { setIsElectiveLoading(false); }
    };

    const handleGetAstrocartographyReport = async () => {
        if (!astrocartographyGoal) {
            setAstrocartographyError("Por favor, especifica tu objetivo.");
            return;
        }
        setIsAstrocartographyLoading(true); setAstrocartographyError(null); setAstrocartographyReport(null);
        try {
            const birthData = `Fecha: ${formData.date}, Hora: ${formData.time}, Lugar: ${formData.place}`;
            const data = await getAstrocartographyReport(birthData, astrocartographyGoal);
            setAstrocartographyReport(data);
        } catch (err) { setAstrocartographyError('No se pudo generar el informe de astrocartografía.'); }
        finally { setIsAstrocartographyLoading(false); }
    };

    const isMainFormValid = formData.date && formData.time && formData.place;

    return (
        <section className="max-w-4xl mx-auto p-4 md:p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                    Astrología Electiva y de Ubicación
                </h2>
                {!isDataSubmitted ? (
                    <>
                        <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                           Ingresa tus datos de nacimiento para elegir el mejor momento para tus eventos importantes y descubrir los lugares del mundo más favorables para ti.
                        </p>
                        <form onSubmit={handleMainFormSubmit} className="space-y-6">
                             <div className="grid md:grid-cols-3 gap-4">
                                <div>
                                    <label htmlFor="date" className="block text-left text-sm font-medium text-gray-300 mb-2">Fecha de Nacimiento</label>
                                    <input type="date" id="date" name="date" value={formData.date} onChange={handleMainFormChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required max={new Date().toISOString().split("T")[0]} />
                                </div>
                                <div>
                                    <label htmlFor="time" className="block text-left text-sm font-medium text-gray-300 mb-2">Hora de Nacimiento</label>
                                    <input type="time" id="time" name="time" value={formData.time} onChange={handleMainFormChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required />
                                </div>
                                <div>
                                    <label htmlFor="place" className="block text-left text-sm font-medium text-gray-300 mb-2">Lugar de Nacimiento</label>
                                    <input type="text" id="place" name="place" value={formData.place} onChange={handleMainFormChange} placeholder="Ciudad, País" className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all placeholder:text-gray-400" required />
                                </div>
                            </div>
                            <button type="submit" disabled={!isMainFormValid || isLoading} className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">
                                {isLoading ? 'Validando...' : 'Acceder a Informes'}
                            </button>
                        </form>
                    </>
                ) : (
                     <div className="mt-8 space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <ReportGeneratorCard title="Astrología Electiva" description="Elige el momento astrológicamente más propicio para iniciar algo importante." buttonText="Encontrar Mejor Momento" isLoading={isElectiveLoading} error={electiveError} onGenerate={handleGetElectiveReport}>
                                {!electiveReport && (
                                    <div className="space-y-3 text-left text-sm">
                                        <input type="text" placeholder="Objetivo (ej. Casarse)" value={electiveFormData.event} onChange={(e) => setElectiveFormData({...electiveFormData, event: e.target.value})} className="w-full bg-white/10 border-white/20 rounded px-3 py-2 placeholder:text-gray-400" />
                                        <div><label className="text-xs text-gray-300">Rango de Fechas (Inicio)</label><input type="date" value={electiveFormData.startDate} onChange={(e) => setElectiveFormData({...electiveFormData, startDate: e.target.value})} className="w-full bg-white/10 border-white/20 rounded px-3 py-2" /></div>
                                        <div><label className="text-xs text-gray-300">Rango de Fechas (Fin)</label><input type="date" value={electiveFormData.endDate} onChange={(e) => setElectiveFormData({...electiveFormData, endDate: e.target.value})} className="w-full bg-white/10 border-white/20 rounded px-3 py-2" /></div>
                                    </div>
                                )}
                                {electiveReport && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                     <ul className="list-disc list-inside ml-2 space-y-2">{electiveReport.recommendations.map(r => <li key={r.date}><strong>{r.date} a las {r.time}:</strong> {r.justification}</li>)}</ul>
                                </div>)}
                            </ReportGeneratorCard>
                             <ReportGeneratorCard title="Astrocartografía" description="Encuentra los mejores lugares del mundo para vivir, trabajar o viajar." buttonText="Generar Mapa y Análisis" isLoading={isAstrocartographyLoading} error={astrocartographyError} onGenerate={handleGetAstrocartographyReport}>
                                {!astrocartographyReport && (
                                     <div className="space-y-3 text-left text-sm">
                                        <input type="text" placeholder="Objetivo (ej. Impulsar carrera)" value={astrocartographyGoal} onChange={(e) => setAstrocartographyGoal(e.target.value)} className="w-full bg-white/10 border-white/20 rounded px-3 py-2 placeholder:text-gray-400" />
                                    </div>
                                )}
                                {astrocartographyReport && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                    <img src={`data:image/png;base64,${astrocartographyReport.mapImage}`} alt="Mapa de Astrocartografía" className="rounded-lg mb-4 border border-white/20"/>
                                    <p className="whitespace-pre-wrap">{astrocartographyReport.interpretation}</p>
                                </div>)}
                            </ReportGeneratorCard>
                        </div>
                         <button onClick={() => setIsDataSubmitted(false)} className="bg-gray-600/50 hover:bg-gray-500/50 text-white font-bold py-2 px-6 rounded-lg transition-all">
                                Cambiar Datos
                         </button>
                    </div>
                )}
            </div>
            {isLoading && <Loader />}
        </section>
    );
};

export default ElectiveAstrologySection;