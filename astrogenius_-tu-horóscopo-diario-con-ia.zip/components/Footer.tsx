
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer className="bg-black/20 backdrop-blur-sm mt-16 py-8">
            <div className="container mx-auto px-4 text-center text-gray-400">
                {/* AdSense Footer Placeholder */}
                <div className="mb-6 h-20 bg-white/5 rounded-lg flex items-center justify-center text-gray-500 text-sm">
                    Espacio para Anuncio (Footer)
                </div>
                <div className="flex justify-center space-x-4 mb-4">
                    <a href="#" className="hover:text-purple-400 transition-colors">Política de Privacidad</a>
                    <a href="#" className="hover:text-purple-400 transition-colors">Términos de Uso</a>
                    <a href="#" className="hover:text-purple-400 transition-colors">Contacto</a>
                </div>
                <p className="text-sm mb-2">
                    © {new Date().getFullYear()} AstroGenius. Todos los derechos reservados.
                </p>
                <p className="text-xs text-gray-500">
                    Disclaimer: El contenido de este sitio es solo para fines de entretenimiento. Las predicciones no deben ser tomadas como consejo profesional.
                </p>
            </div>
        </footer>
    );
};

export default Footer;
