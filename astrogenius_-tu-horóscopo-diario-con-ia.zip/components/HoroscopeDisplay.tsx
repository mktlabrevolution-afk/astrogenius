
import React from 'react';
import { HoroscopeData, ZodiacSign } from '../types';

interface HoroscopeDisplayProps {
    horoscope: HoroscopeData;
    zodiacSign: ZodiacSign | null;
}

const CategoryCard: React.FC<{ icon: string; title: string; text: string; delay: number }> = ({ icon, title, text, delay }) => {
    return (
        <div 
            className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg transform hover:-translate-y-2 transition-all duration-300 animate-fade-in-up"
            style={{ animationDelay: `${delay}ms` }}
        >
            <div className="flex items-center mb-3">
                <span className="text-3xl mr-3">{icon}</span>
                <h3 className="text-xl font-semibold text-purple-300">{title}</h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">{text}</p>
        </div>
    );
};

const HoroscopeDisplay: React.FC<HoroscopeDisplayProps> = ({ horoscope, zodiacSign }) => {
    if (!horoscope || !zodiacSign) return null;

    const { amor, trabajo, salud, finanzas, consejo, numerosSuerte, colorSuerte } = horoscope;

    return (
        <div className="space-y-8">
            <h2 className="text-center text-3xl font-bold animate-fade-in">
                Horóscopo de hoy para <span className="text-purple-400">{zodiacSign.name} {zodiacSign.icon}</span>
            </h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <CategoryCard icon="❤️" title="Amor" text={amor} delay={100} />
                <CategoryCard icon="💼" title="Trabajo" text={trabajo} delay={200} />
                <CategoryCard icon="🏥" title="Salud" text={salud} delay={300} />
                <CategoryCard icon="💰" title="Finanzas" text={finanzas} delay={400} />
                <div 
                    className="md:col-span-2 lg:col-span-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-6 shadow-lg animate-fade-in-up"
                    style={{ animationDelay: '500ms' }}
                >
                     <div className="flex items-center mb-3">
                        <span className="text-3xl mr-3">💡</span>
                        <h3 className="text-xl font-semibold text-white">Consejo del Día</h3>
                    </div>
                    <p className="text-white text-lg italic">{consejo}</p>
                </div>
            </div>
            
            <div 
                className="flex flex-col md:flex-row justify-center items-center gap-6 text-center animate-fade-in-up"
                style={{ animationDelay: '600ms' }}
            >
                <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-4 shadow-lg w-full md:w-auto">
                    <h4 className="text-lg font-semibold text-purple-300 mb-2">Números de la Suerte</h4>
                    <div className="flex justify-center space-x-4">
                        {numerosSuerte.map(num => (
                            <span key={num} className="text-2xl font-bold bg-white/10 px-4 py-2 rounded-md">{num}</span>
                        ))}
                    </div>
                </div>
                 <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-4 shadow-lg w-full md:w-auto">
                    <h4 className="text-lg font-semibold text-purple-300 mb-2">Color Favorable</h4>
                    <div className="flex items-center justify-center gap-3">
                        <div className="w-8 h-8 rounded-full border-2 border-white" style={{ backgroundColor: colorSuerte.toLowerCase() }}></div>
                        <span className="text-2xl font-bold">{colorSuerte}</span>
                    </div>
                </div>
            </div>
            <div className="flex justify-center mt-6">
                {/* AdSense In-Content Placeholder */}
                <div className="mt-8 h-20 w-full max-w-2xl bg-white/5 rounded-lg flex items-center justify-center text-gray-500 text-sm">
                    Espacio para Anuncio (In-Content)
                </div>
            </div>
        </div>
    );
};

export default HoroscopeDisplay;
