
import React from 'react';

const blogPosts = [
    {
        title: "Cómo Leer tu Carta Natal Completa: Una Guía para Principiantes",
        excerpt: "Descubre los secretos de tu carta astral. Aprende sobre los planetas, las casas y los aspectos que definen tu personalidad y destino.",
        tags: ["Astrología", "Carta Natal", "Principiantes"]
    },
    {
        title: "Compatibilidad Amorosa entre Signos: ¿Mito o Realidad?",
        excerpt: "Analizamos las dinámicas de pareja entre los diferentes signos del zodiaco. ¿Son los opuestos los que se atraen? ¿Qué dice la sinastría sobre tu relación?",
        tags: ["Amor", "Compatibilidad", "Relaciones"]
    },
    {
        title: "La Influencia de los Planetas Retrógrados en tu Vida Diaria",
        excerpt: "Mercurio retrógrado es el más famoso, pero no es el único. Entiende cómo los ciclos planetarios pueden afectar tu comunicación, tus emociones y tus proyectos.",
        tags: ["Planetas", "Mercurio Retrógrado", "Ciclos"]
    }
];

const BlogCard: React.FC<{ post: typeof blogPosts[0] }> = ({ post }) => (
    <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg transform hover:-translate-y-2 transition-all duration-300 flex flex-col">
        <h3 className="text-xl font-semibold text-purple-300 mb-2">{post.title}</h3>
        <p className="text-gray-300 text-sm leading-relaxed flex-grow">{post.excerpt}</p>
        <div className="mt-4 flex flex-wrap gap-2">
            {post.tags.map(tag => (
                <span key={tag} className="text-xs bg-purple-500/50 text-white px-2 py-1 rounded-full">{tag}</span>
            ))}
        </div>
        <button className="mt-4 text-left text-pink-400 hover:text-pink-300 font-semibold">Leer más →</button>
    </div>
);


const BlogSection: React.FC = () => {
    return (
        <div className="max-w-6xl mx-auto p-8 animate-fade-in">
            <h2 className="text-3xl font-bold text-center mb-8 text-purple-400">Nuestro Blog Astrológico</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts.map((post, index) => <BlogCard key={index} post={post} />)}
            </div>
        </div>
    );
};

export default BlogSection;
