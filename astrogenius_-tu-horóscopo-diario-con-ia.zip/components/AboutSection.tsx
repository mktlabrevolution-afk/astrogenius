
import React from 'react';

const AboutSection: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <h2 className="text-3xl font-bold text-center mb-6 text-purple-400">Acerca de AstroGenius</h2>
            
            <div className="space-y-6 text-gray-300">
                <section>
                    <h3 className="text-xl font-semibold mb-2 text-white">Nuestra Metodología (Expertise)</h3>
                    <p>En AstroGenius, combinamos la sabiduría ancestral de la astrología con el poder de la inteligencia artificial de vanguardia. Nuestros horóscopos son generados utilizando la API de Gemini de Google, entrenada para interpretar las alineaciones planetarias diarias y su influencia en cada signo zodiacal. Este enfoque híbrido nos permite ofrecer predicciones que son a la vez personalizadas, relevantes y positivas, manteniendo siempre un tono realista y orientador.</p>
                </section>

                <section>
                    <h3 className="text-xl font-semibold mb-2 text-white">Experiencias de Nuestros Usuarios (Experience)</h3>
                    <div className="space-y-4">
                        <blockquote className="border-l-4 border-purple-500 pl-4 italic">
                            <p>"¡Increíblemente acertado! El consejo del día me ayudó a tomar una decisión importante en el trabajo. Se ha convertido en mi ritual matutino."</p>
                            <footer className="text-right text-purple-300 mt-1">- Ana G.</footer>
                        </blockquote>
                        <blockquote className="border-l-4 border-purple-500 pl-4 italic">
                            <p>"Me encanta el diseño y lo fácil que es de usar. Las predicciones son positivas y me dan un buen empujón para empezar el día."</p>
                            <footer className="text-right text-purple-300 mt-1">- Carlos M.</footer>
                        </blockquote>
                    </div>
                </section>
                
                <section>
                    <h3 className="text-xl font-semibold mb-2 text-white">Confianza y Transparencia (Trustworthiness)</h3>
                    <p>Tu privacidad es importante para nosotros. No almacenamos tu fecha de nacimiento ni ningún dato personal. Los horóscopos generados se guardan de forma anónima en la caché de tu navegador para mejorar la velocidad y evitar llamadas innecesarias a la API. Para más detalles, consulta nuestra Política de Privacidad.</p>
                </section>
                
                <div className="text-center pt-4">
                    <p className="font-bold text-lg text-white">Usuarios Activos Hoy: <span className="text-green-400">{Math.floor(1000 + Math.random() * 9000)}</span></p>
                </div>
            </div>
        </div>
    );
};

export default AboutSection;
