import React from 'react';
import { ZodiacSign } from '../types';

interface ZodiacSelectorProps {
    birthDate: string;
    onDateChange: (date: string) => void;
    zodiacSign: ZodiacSign | null;
    onGenerate: () => void;
    isLoading: boolean;
}

const ZodiacSelector: React.FC<ZodiacSelectorProps> = ({ birthDate, onDateChange, zodiacSign, onGenerate, isLoading }) => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const maxDate = `${yyyy}-${mm}-${dd}`;

    return (
        <section className="text-center mb-12 p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in-down">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                Descubre tu Destino
            </h2>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                Ingresa tu fecha de nacimiento para que nuestra IA genere tu horóscopo personalizado para el día de hoy.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
                <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => onDateChange(e.target.value)}
                    className="bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all w-full sm:w-auto"
                    max={maxDate}
                />
                <button
                    onClick={onGenerate}
                    disabled={!zodiacSign || isLoading}
                    className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300"
                >
                    {isLoading ? 'Generando...' : 'Generar Horóscopo'}
                </button>
            </div>
            {zodiacSign && (
                <div className="animate-fade-in bg-white/5 p-4 rounded-xl inline-flex items-center gap-4">
                    <span className="text-5xl">{zodiacSign.icon}</span>
                    <div>
                        <p className="text-lg text-gray-300">Tu signo es:</p>
                        <p className="text-2xl font-bold text-white">{zodiacSign.name}</p>
                        <p className="text-sm text-gray-400">{zodiacSign.range}</p>
                    </div>
                </div>
            )}
        </section>
    );
};

export default ZodiacSelector;