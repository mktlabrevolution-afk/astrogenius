import React from 'react';
import { View } from '../types';

interface HeaderProps {
    setView: (view: View) => void;
    currentView: View;
}

const NavLink: React.FC<{ view: View; currentView: View; setView: (view: View) => void; children: React.ReactNode }> = ({ view, currentView, setView, children }) => {
    const isActive = currentView === view;
    return (
        <button
            onClick={() => setView(view)}
            className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-300 ${isActive ? 'bg-purple-500 text-white shadow-lg' : 'text-gray-300 hover:bg-white/10 hover:text-white'}`}
        >
            {children}
        </button>
    );
}

const Header: React.FC<HeaderProps> = ({ setView, currentView }) => {
    return (
        <header className="bg-black/20 backdrop-blur-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
                <div className="flex items-center space-x-2 mb-4 md:mb-0">
                    <span className="text-3xl">🔮</span>
                    <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                        AstroGenius
                    </h1>
                </div>
                <nav className="flex flex-wrap justify-center items-center space-x-1">
                    <NavLink view="horoscope" currentView={currentView} setView={setView}>Horóscopo</NavLink>
                    <NavLink view="astral_chart" currentView={currentView} setView={setView}>Carta Astral</NavLink>
                    <NavLink view="compatibility" currentView={currentView} setView={setView}>Compatibilidad</NavLink>
                    <NavLink view="relationships" currentView={currentView} setView={setView}>Relaciones</NavLink>
                    <NavLink view="predictive" currentView={currentView} setView={setView}>Predictiva</NavLink>
                    <NavLink view="karmic" currentView={currentView} setView={setView}>Kármica</NavLink>
                    <NavLink view="elective" currentView={currentView} setView={setView}>Electiva</NavLink>
                    <NavLink view="blog" currentView={currentView} setView={setView}>Blog</NavLink>
                    <NavLink view="faq" currentView={currentView} setView={setView}>FAQ</NavLink>
                    <NavLink view="about" currentView={currentView} setView={setView}>Acerca de</NavLink>
                </nav>
            </div>
        </header>
    );
};

export default Header;