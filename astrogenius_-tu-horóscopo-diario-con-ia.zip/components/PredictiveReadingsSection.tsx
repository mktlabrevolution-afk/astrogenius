import React, { useState } from 'react';
import { getSolarReturn, getTransits } from '../services/geminiService';
import { SolarReturnData, TransitData } from '../types';
import ReportGeneratorCard from './ReportGeneratorCard';
import Loader from './Loader';

const PredictiveReadingsSection: React.FC = () => {
    const [formData, setFormData] = useState({ date: '', time: '', place: '' });
    const [isDataSubmitted, setIsDataSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [solarReturn, setSolarReturn] = useState<SolarReturnData | null>(null);
    const [isSolarReturnLoading, setIsSolarReturnLoading] = useState(false);
    const [solarReturnError, setSolarReturnError] = useState<string | null>(null);

    const [transits, setTransits] = useState<TransitData | null>(null);
    const [isTransitsLoading, setIsTransitsLoading] = useState(false);
    const [transitsError, setTransitsError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate a small delay to show loader, then show report generators
        setTimeout(() => {
            setIsDataSubmitted(true);
            setIsLoading(false);
        }, 500);
    };

    const handleGetSolarReturn = async () => {
        setIsSolarReturnLoading(true); setSolarReturnError(null); setSolarReturn(null);
        try {
            const data = await getSolarReturn(formData.date);
            setSolarReturn(data);
        } catch (err) { setSolarReturnError('No se pudo generar el informe de Revolución Solar.'); }
        finally { setIsSolarReturnLoading(false); }
    };

    const handleGetTransits = async () => {
        setIsTransitsLoading(true); setTransitsError(null); setTransits(null);
        try {
            const data = await getTransits(formData.date, formData.time, formData.place);
            setTransits(data);
        } catch (err) { setTransitsError('No se pudo generar el informe de Tránsitos.'); }
        finally { setIsTransitsLoading(false); }
    };

    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const maxDate = `${yyyy}-${mm}-${dd}`;

    const isFormValid = formData.date && formData.time && formData.place;

    return (
        <section className="max-w-4xl mx-auto p-4 md:p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                    Lecturas Predictivas y de Tránsito
                </h2>
                {!isDataSubmitted ? (
                    <>
                        <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                            Ingresa tus datos de nacimiento para acceder a las herramientas de predicción astrológica y descubrir las energías que te depara el futuro.
                        </p>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid md:grid-cols-3 gap-4">
                                <div>
                                    <label htmlFor="date" className="block text-left text-sm font-medium text-gray-300 mb-2">Fecha de Nacimiento</label>
                                    <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required max={maxDate} />
                                </div>
                                <div>
                                    <label htmlFor="time" className="block text-left text-sm font-medium text-gray-300 mb-2">Hora de Nacimiento</label>
                                    <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required />
                                </div>
                                <div>
                                    <label htmlFor="place" className="block text-left text-sm font-medium text-gray-300 mb-2">Lugar de Nacimiento</label>
                                    <input type="text" id="place" name="place" value={formData.place} onChange={handleChange} placeholder="Ciudad, País" className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all placeholder:text-gray-400" required />
                                </div>
                            </div>
                            <button type="submit" disabled={!isFormValid || isLoading} className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">
                                {isLoading ? 'Validando...' : 'Acceder a Informes'}
                            </button>
                        </form>
                    </>
                ) : (
                     <div className="mt-8 space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <ReportGeneratorCard title="Revolución Solar" description="Predice los temas de tu año de cumpleaños a cumpleaños." buttonText="Generar Informe Anual" isLoading={isSolarReturnLoading} error={solarReturnError} onGenerate={handleGetSolarReturn}>
                                {solarReturn && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                    <p><strong className="text-white">Tema del Año:</strong> {solarReturn.themeOfYear}</p>
                                    <div><strong className="text-white">Áreas Clave:</strong><ul className="list-disc list-inside ml-4">{solarReturn.keyAreas.map(a => <li key={a.area}><strong>{a.area}:</strong> {a.focus}</li>)}</ul></div>
                                    <p><strong className="text-white">Consejo:</strong> {solarReturn.advice}</p>
                                </div>)}
                            </ReportGeneratorCard>
                            <ReportGeneratorCard title="Tránsitos y Progresiones" description="Analiza el impacto de los planetas en tu carta para los próximos 6 meses." buttonText="Generar Previsión" isLoading={isTransitsLoading} error={transitsError} onGenerate={handleGetTransits}>
                                {transits && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                    <p><strong className="text-white">Panorama General:</strong> {transits.overview}</p>
                                    <div><strong className="text-white">Tránsitos Clave:</strong><ul className="list-disc list-inside ml-4">{transits.keyTransits.map(t => <li key={t.planet + t.aspect}><strong>{t.date}:</strong> {t.planet} {t.aspect} - {t.influence}</li>)}</ul></div>
                                </div>)}
                            </ReportGeneratorCard>
                        </div>
                         <button onClick={() => setIsDataSubmitted(false)} className="bg-gray-600/50 hover:bg-gray-500/50 text-white font-bold py-2 px-6 rounded-lg transition-all">
                                Cambiar Datos
                         </button>
                    </div>
                )}
            </div>
            {isLoading && <Loader />}
        </section>
    );
};

export default PredictiveReadingsSection;