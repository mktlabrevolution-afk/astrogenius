import React, { useState } from 'react';
import { getAstralChart } from '../services/geminiService';
import { AstralChartData } from '../types';
import Loader from './Loader';

interface AstralChartDisplayProps {
    data: AstralChartData;
    onReset: () => void;
}

const AstralChartDisplay: React.FC<AstralChartDisplayProps> = ({ data, onReset }) => {
    const planetIcons: { [key: string]: string } = {
        'sol': '☀️', 'luna': '🌙', 'ascendente': '🌅', 'mercurio': '☿️',
        'venus': '♀️', 'marte': '♂️',
    };

    return (
        <div className="space-y-8 animate-fade-in">
            <h2 className="text-center text-3xl font-bold">Tu Carta Astral <span className="text-purple-400">Revelada</span></h2>
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-6 shadow-lg">
                <h3 className="text-xl font-semibold text-white mb-2">Resumen Cósmico</h3>
                <p className="text-white text-lg italic">{data.summary}</p>
            </div>
            <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg"><h3 className="text-xl font-semibold text-purple-300 mb-3 flex items-center">{planetIcons['sol']} Tu Sol en {data.sunSign}</h3><p className="text-gray-300 text-sm leading-relaxed">{data.sunInterpretation}</p></div>
                <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg"><h3 className="text-xl font-semibold text-purple-300 mb-3 flex items-center">{planetIcons['luna']} Tu Luna en {data.moonSign}</h3><p className="text-gray-300 text-sm leading-relaxed">{data.moonInterpretation}</p></div>
                <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg"><h3 className="text-xl font-semibold text-purple-300 mb-3 flex items-center">{planetIcons['ascendente']} Tu Ascendente en {data.ascendantSign}</h3><p className="text-gray-300 text-sm leading-relaxed">{data.ascendantInterpretation}</p></div>
            </div>
             <div>
                <h3 className="text-2xl font-bold text-center mb-4">Planetas Personales Clave</h3>
                 <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-6">
                    {data.keyPlanets.map(p => (<div key={p.planet} className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg"><h4 className="text-lg font-semibold text-purple-300 mb-2 flex items-center">{planetIcons[p.planet.toLowerCase()]} {p.planet} en {p.sign}</h4><p className="text-gray-300 text-sm leading-relaxed">{p.interpretation}</p></div>))}
                </div>
            </div>

            <div className="text-center mt-8">
                <button onClick={onReset} className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">Generar Otra Carta</button>
            </div>
            <div className="mt-8 h-20 w-full max-w-2xl mx-auto bg-white/5 rounded-lg flex items-center justify-center text-gray-500 text-sm">Espacio para Anuncio (In-Content)</div>
        </div>
    );
};


const AstralChartSection: React.FC = () => {
    const [formData, setFormData] = useState({ date: '', time: '', place: '' });
    const [chartData, setChartData] = useState<AstralChartData | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const maxDate = `${yyyy}-${mm}-${dd}`;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError(null);
        setChartData(null);
        try {
            const data = await getAstralChart(formData.date, formData.time, formData.place);
            setChartData(data);
        } catch (err) {
            console.error(err);
            setError('No se pudo generar tu carta astral. Por favor, revisa los datos o intenta de nuevo más tarde.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleReset = () => {
        setChartData(null);
        setFormData({ date: '', time: '', place: '' });
        setError(null);
    };
    
    const isFormValid = formData.date && formData.time && formData.place;

    return (
        <section className="max-w-4xl mx-auto p-4 md:p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            {!chartData && !isLoading && (
                 <div className="text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                        Crea tu Carta Astral
                    </h2>
                    <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                        La carta astral es un mapa del cielo en el momento exacto de tu nacimiento. Ingresa tus datos para revelar una visión profunda de tu personalidad, potenciales y camino de vida.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid md:grid-cols-3 gap-4">
                            <div>
                                <label htmlFor="date" className="block text-left text-sm font-medium text-gray-300 mb-2">Fecha de Nacimiento</label>
                                <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required max={maxDate} />
                            </div>
                            <div>
                                <label htmlFor="time" className="block text-left text-sm font-medium text-gray-300 mb-2">Hora de Nacimiento</label>
                                <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required />
                            </div>
                             <div>
                                <label htmlFor="place" className="block text-left text-sm font-medium text-gray-300 mb-2">Lugar de Nacimiento</label>
                                <input type="text" id="place" name="place" value={formData.place} onChange={handleChange} placeholder="Ciudad, País" className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all placeholder:text-gray-400" required />
                            </div>
                        </div>
                        <button type="submit" disabled={!isFormValid || isLoading} className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">
                            Generar Carta Astral
                        </button>
                    </form>
                </div>
            )}
            {isLoading && <Loader />}
            {error && <p className="text-center text-red-400 mt-4 animate-fade-in">{error}</p>}
            {chartData && <AstralChartDisplay 
                data={chartData} 
                onReset={handleReset} 
            />}
        </section>
    );
};

export default AstralChartSection;