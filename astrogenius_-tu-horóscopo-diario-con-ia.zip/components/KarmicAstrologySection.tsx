import React, { useState } from 'react';
import { getKarmicAstrologyReport, getPsychoAstrologyReport } from '../services/geminiService';
import { KarmicAstrologyData, PsychoAstrologyData } from '../types';
import ReportGeneratorCard from './ReportGeneratorCard';
import Loader from './Loader';

const KarmicAstrologySection: React.FC = () => {
    const [formData, setFormData] = useState({ date: '', time: '', place: '' });
    const [isDataSubmitted, setIsDataSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [karmicReport, setKarmicReport] = useState<KarmicAstrologyData | null>(null);
    const [isKarmicLoading, setIsKarmicLoading] = useState(false);
    const [karmicError, setKarmicError] = useState<string | null>(null);

    const [psychoReport, setPsychoReport] = useState<PsychoAstrologyData | null>(null);
    const [isPsychoLoading, setIsPsychoLoading] = useState(false);
    const [psychoError, setPsychoError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            setIsDataSubmitted(true);
            setIsLoading(false);
        }, 500);
    };

    const handleGetKarmicReport = async () => {
        setIsKarmicLoading(true); setKarmicError(null); setKarmicReport(null);
        try {
            const data = await getKarmicAstrologyReport(formData.date, formData.time, formData.place);
            setKarmicReport(data);
        } catch (err) { setKarmicError('No se pudo generar el informe kármico.'); }
        finally { setIsKarmicLoading(false); }
    };

    const handleGetPsychoReport = async () => {
        setIsPsychoLoading(true); setPsychoError(null); setPsychoReport(null);
        try {
            const data = await getPsychoAstrologyReport(formData.date, formData.time, formData.place);
            setPsychoReport(data);
        } catch (err) { setPsychoError('No se pudo generar el informe psicológico.'); }
        finally { setIsPsychoLoading(false); }
    };

    const isFormValid = formData.date && formData.time && formData.place;

    return (
        <section className="max-w-4xl mx-auto p-4 md:p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                    Astrología Kármica y Psicológica
                </h2>
                {!isDataSubmitted ? (
                    <>
                        <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                            Ingresa tus datos de nacimiento para explorar tu propósito de vida, lecciones kármicas, necesidades emocionales y potencial de sanación.
                        </p>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div className="grid md:grid-cols-3 gap-4">
                                <div>
                                    <label htmlFor="date" className="block text-left text-sm font-medium text-gray-300 mb-2">Fecha de Nacimiento</label>
                                    <input type="date" id="date" name="date" value={formData.date} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required max={new Date().toISOString().split("T")[0]} />
                                </div>
                                <div>
                                    <label htmlFor="time" className="block text-left text-sm font-medium text-gray-300 mb-2">Hora de Nacimiento</label>
                                    <input type="time" id="time" name="time" value={formData.time} onChange={handleChange} className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all" required />
                                </div>
                                <div>
                                    <label htmlFor="place" className="block text-left text-sm font-medium text-gray-300 mb-2">Lugar de Nacimiento</label>
                                    <input type="text" id="place" name="place" value={formData.place} onChange={handleChange} placeholder="Ciudad, País" className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-purple-500 focus:outline-none transition-all placeholder:text-gray-400" required />
                                </div>
                            </div>
                            <button type="submit" disabled={!isFormValid || isLoading} className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">
                                {isLoading ? 'Validando...' : 'Acceder a Informes'}
                            </button>
                        </form>
                    </>
                ) : (
                     <div className="mt-8 space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                             <ReportGeneratorCard title="Nodos Lunares y Retorno Planetario" description="Explora tu propósito de vida, lecciones kármicas y grandes ciclos de madurez." buttonText="Generar Ensayo Kármico" isLoading={isKarmicLoading} error={karmicError} onGenerate={handleGetKarmicReport}>
                                {karmicReport && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                     <p><strong className="text-white">{karmicReport.reportTitle}</strong></p>
                                     <p className="whitespace-pre-wrap">{karmicReport.essay}</p>
                                </div>)}
                            </ReportGeneratorCard>
                            <ReportGeneratorCard title="Análisis de Luna y Quirón" description="Profundiza en tus necesidades emocionales, tu inconsciente y tus heridas para sanar." buttonText="Generar Análisis Psicológico" isLoading={isPsychoLoading} error={psychoError} onGenerate={handleGetPsychoReport}>
                                {psychoReport && (<div className="text-sm space-y-4 text-gray-300 text-left">
                                    <div>
                                        <p><strong className="text-white">{psychoReport.moonAnalysis.title}</strong></p>
                                        <p className="whitespace-pre-wrap">{psychoReport.moonAnalysis.analysis}</p>
                                    </div>
                                     <div>
                                        <p><strong className="text-white">{psychoReport.chironAnalysis.title}</strong></p>
                                        <p className="whitespace-pre-wrap">{psychoReport.chironAnalysis.analysis}</p>
                                    </div>
                                </div>)}
                            </ReportGeneratorCard>
                        </div>
                         <button onClick={() => setIsDataSubmitted(false)} className="bg-gray-600/50 hover:bg-gray-500/50 text-white font-bold py-2 px-6 rounded-lg transition-all">
                                Cambiar Datos
                         </button>
                    </div>
                )}
            </div>
            {isLoading && <Loader />}
        </section>
    );
};

export default KarmicAstrologySection;