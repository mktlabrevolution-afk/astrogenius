
import React, { useState } from 'react';

const faqs = [
    {
        q: "¿Cómo se calcula mi signo zodiacal?",
        a: "Tu signo zodiacal se determina por la posición del sol en el momento de tu nacimiento. Nuestra aplicación calcula automáticamente tu signo basándose en la fecha que proporcionas, siguiendo las fechas estándar de la astrología occidental."
    },
    {
        q: "¿Qué tan precisos son los horóscopos generados por IA?",
        a: "Nuestros horóscopos son generados por la IA de Google (Gemini) y están diseñados para ofrecer orientación e inspiración. Si bien muchos usuarios los encuentran sorprendentemente acertados, deben considerarse como una herramienta de entretenimiento y autoconocimiento, no como predicciones literales del futuro."
    },
    {
        q: "¿Con qué frecuencia se actualizan los horóscopos?",
        a: "Los horóscopos se generan para cada día. La aplicación guarda en caché la predicción de tu signo durante 24 horas para garantizar que recibas la misma lectura consistente a lo largo del día y para optimizar el rendimiento."
    },
    {
        q: "¿Mis datos personales están seguros?",
        a: "Absolutamente. No guardamos tu fecha de nacimiento en nuestros servidores. Todo el cálculo y el almacenamiento en caché se realizan directamente en tu navegador. Tu privacidad es nuestra máxima prioridad."
    }
];

const FAQItem: React.FC<{ faq: { q: string, a: string } }> = ({ faq }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="border-b border-white/10">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center py-4 text-left text-lg font-semibold text-white"
            >
                <span>{faq.q}</span>
                <span className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : 'rotate-0'}`}>▼</span>
            </button>
            <div className={`overflow-hidden transition-all duration-500 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                <p className="py-4 text-gray-300">{faq.a}</p>
            </div>
        </div>
    );
};

const FAQSection: React.FC = () => {
    return (
        <div className="max-w-4xl mx-auto p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <h2 className="text-3xl font-bold text-center mb-6 text-purple-400">Preguntas Frecuentes</h2>
            <div className="space-y-2">
                {faqs.map((faq, index) => <FAQItem key={index} faq={faq} />)}
            </div>
        </div>
    );
};

export default FAQSection;
