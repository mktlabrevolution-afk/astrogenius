import React, { useState } from 'react';
import { getSynastryReport, getCompositeChartReport } from '../services/geminiService';
import { SynastryData, CompositeChartData } from '../types';
import ReportGeneratorCard from './ReportGeneratorCard';
import Loader from './Loader';

const RelationshipAstrologySection: React.FC = () => {
    const [person1, setPerson1] = useState({ date: '', time: '', place: '' });
    const [person2, setPerson2] = useState({ date: '', time: '', place: '' });
    const [isDataSubmitted, setIsDataSubmitted] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    const [synastry, setSynastry] = useState<SynastryData | null>(null);
    const [isSynastryLoading, setIsSynastryLoading] = useState(false);
    const [synastryError, setSynastryError] = useState<string | null>(null);

    const [composite, setComposite] = useState<CompositeChartData | null>(null);
    const [isCompositeLoading, setIsCompositeLoading] = useState(false);
    const [compositeError, setCompositeError] = useState<string | null>(null);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>, person: 'person1' | 'person2') => {
        const setter = person === 'person1' ? setPerson1 : setPerson2;
        const data = person === 'person1' ? person1 : person2;
        setter({ ...data, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setTimeout(() => {
            setIsDataSubmitted(true);
            setIsLoading(false);
        }, 500);
    };

    const getPersonDataString = (person: { date: string, time: string, place: string }) => {
        return `Fecha: ${person.date}, Hora: ${person.time}, Lugar: ${person.place}`;
    };

    const handleGetSynastry = async () => {
        setIsSynastryLoading(true); setSynastryError(null); setSynastry(null);
        try {
            const data = await getSynastryReport(getPersonDataString(person1), getPersonDataString(person2));
            setSynastry(data);
        } catch (err) { setSynastryError('No se pudo generar el informe de Sinastría.'); }
        finally { setIsSynastryLoading(false); }
    };

    const handleGetComposite = async () => {
        setIsCompositeLoading(true); setCompositeError(null); setComposite(null);
        try {
            const data = await getCompositeChartReport(getPersonDataString(person1), getPersonDataString(person2));
            setComposite(data);
        } catch (err) { setCompositeError('No se pudo generar la Carta Compuesta.'); }
        finally { setIsCompositeLoading(false); }
    };

    const isFormValid = person1.date && person1.time && person1.place && person2.date && person2.time && person2.place;

    const PersonForm: React.FC<{ person: 'person1' | 'person2' }> = ({ person }) => {
        const data = person === 'person1' ? person1 : person2;
        return (
            <div className="space-y-4 p-4 bg-white/5 rounded-lg">
                <h3 className="font-semibold text-lg text-white">Persona {person === 'person1' ? 1 : 2}</h3>
                <div className="grid md:grid-cols-3 gap-4">
                     <div>
                        <label className="block text-left text-xs font-medium text-gray-300 mb-1">Fecha de Nacimiento</label>
                        <input type="date" name="date" value={data.date} onChange={(e) => handleChange(e, person)} className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-purple-500 focus:outline-none" required max={new Date().toISOString().split("T")[0]} />
                    </div>
                     <div>
                        <label className="block text-left text-xs font-medium text-gray-300 mb-1">Hora de Nacimiento</label>
                        <input type="time" name="time" value={data.time} onChange={(e) => handleChange(e, person)} className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-purple-500 focus:outline-none" required />
                    </div>
                     <div>
                        <label className="block text-left text-xs font-medium text-gray-300 mb-1">Lugar de Nacimiento</label>
                        <input type="text" name="place" value={data.place} onChange={(e) => handleChange(e, person)} placeholder="Ciudad, País" className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-sm text-white focus:ring-2 focus:ring-purple-500 focus:outline-none placeholder:text-gray-400" required />
                    </div>
                </div>
            </div>
        )
    };

    return (
        <section className="max-w-4xl mx-auto p-4 md:p-8 bg-black/20 backdrop-blur-md border border-white/10 rounded-2xl shadow-2xl animate-fade-in">
            <div className="text-center">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-500">
                    Astrología de Relaciones
                </h2>
                {!isDataSubmitted ? (
                    <>
                        <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
                            Ingresa los datos de nacimiento de dos personas para analizar la compatibilidad, los desafíos y el propósito de su unión.
                        </p>
                        <form onSubmit={handleSubmit} className="space-y-6">
                            <PersonForm person="person1" />
                            <PersonForm person="person2" />
                            <button type="submit" disabled={!isFormValid || isLoading} className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 disabled:cursor-not-allowed text-white font-bold py-3 px-8 rounded-lg shadow-lg hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300">
                                {isLoading ? 'Validando...' : 'Analizar Relación'}
                            </button>
                        </form>
                    </>
                ) : (
                     <div className="mt-8 space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <ReportGeneratorCard title="Sinastría (Compatibilidad)" description="Superpone dos cartas para analizar la conexión, desafío y complementariedad." buttonText="Generar Informe de Sinastría" isLoading={isSynastryLoading} error={synastryError} onGenerate={handleGetSynastry}>
                                {synastry && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                    <h5 className="font-bold text-base text-white">{synastry.title}</h5>
                                    <p>{synastry.summary}</p>
                                    <div><strong className="text-green-400">Fortalezas:</strong><ul className="list-disc list-inside ml-4">{synastry.strengths.map(s => <li key={s.aspect}><strong>{s.aspect}:</strong> {s.interpretation}</li>)}</ul></div>
                                     <div><strong className="text-red-400">Desafíos:</strong><ul className="list-disc list-inside ml-4">{synastry.challenges.map(c => <li key={c.aspect}><strong>{c.aspect}:</strong> {c.interpretation}</li>)}</ul></div>
                                </div>)}
                            </ReportGeneratorCard>
                            <ReportGeneratorCard title="Carta Compuesta" description="Crea una tercera 'carta de la relación' para revelar la energía y propósito de la unión." buttonText="Generar Carta Compuesta" isLoading={isCompositeLoading} error={compositeError} onGenerate={handleGetComposite}>
                                 {composite && (<div className="text-sm space-y-3 text-gray-300 text-left">
                                    <h5 className="font-bold text-base text-white">{composite.title}</h5>
                                    <p><strong className="text-white">Propósito de la Relación:</strong> {composite.purpose}</p>
                                    <div><strong className="text-white">Temas Clave:</strong><ul className="list-disc list-inside ml-4">{composite.keyThemes.map(t => <li key={t.theme}><strong>{t.theme}:</strong> {t.interpretation}</li>)}</ul></div>
                                </div>)}
                            </ReportGeneratorCard>
                        </div>
                         <button onClick={() => setIsDataSubmitted(false)} className="bg-gray-600/50 hover:bg-gray-500/50 text-white font-bold py-2 px-6 rounded-lg transition-all">
                                Cambiar Datos
                         </button>
                    </div>
                )}
            </div>
            {isLoading && <Loader />}
        </section>
    );
};

export default RelationshipAstrologySection;