import React from 'react';

const ReportGeneratorCard: React.FC<{
    title: string;
    description: string;
    buttonText: string;
    isLoading: boolean;
    error: string | null;
    onGenerate: () => void;
    children: React.ReactNode;
}> = ({ title, description, buttonText, isLoading, error, onGenerate, children }) => {
    const hasContent = React.Children.count(children) > 0;
    return (
        <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg">
            <h4 className="text-xl font-semibold text-purple-300 mb-3">{title}</h4>
            {!hasContent && !isLoading && <p className="text-gray-400 text-sm mb-4">{description}</p>}
            
            {!hasContent && (
                <button onClick={onGenerate} disabled={isLoading} className="bg-purple-600/80 hover:bg-purple-700/80 disabled:bg-gray-500 text-white font-bold py-2 px-4 rounded-lg text-sm transition-all">
                    {isLoading ? 'Generando...' : buttonText}
                </button>
            )}
            {isLoading && <div className="mt-4"><div className="w-1/2 h-4 bg-white/10 rounded animate-pulse"></div></div>}
            {error && <p className="text-red-400 text-sm mt-4">{error}</p>}
            <div className="mt-4 animate-fade-in">{children}</div>
        </div>
    );
};

export default ReportGeneratorCard;
