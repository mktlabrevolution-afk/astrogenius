
import React from 'react';

const Particles: React.FC = () => {
    const particleCount = 50;
    const particles = Array.from({ length: particleCount }).map((_, i) => {
        const style = {
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 10}s`,
            animationDuration: `${Math.random() * 15 + 10}s`,
            transform: `scale(${Math.random() * 0.5 + 0.5})`,
        };
        return <div key={i} className="particle" style={style}></div>;
    });

    return (
        <>
            <style>
                {`
                .particle {
                    position: absolute;
                    width: 4px;
                    height: 4px;
                    background: white;
                    border-radius: 50%;
                    opacity: 0;
                    animation: float 25s ease-in-out infinite;
                    box-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px #c084fc;
                }

                @keyframes float {
                    0% {
                        transform: translate(0, 0) scale(0.5);
                        opacity: 0;
                    }
                    50% {
                        transform: translate(${Math.random() * 200 - 100}px, ${Math.random() * 200 - 100}px) scale(1);
                        opacity: 0.8;
                    }
                    100% {
                        transform: translate(${Math.random() * 200 - 100}px, ${Math.random() * 200 - 100}px) scale(0.5);
                        opacity: 0;
                    }
                }
                `}
            </style>
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                {particles}
            </div>
        </>
    );
};

export default Particles;
