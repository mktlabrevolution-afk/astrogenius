
import React from 'react';

const SkeletonCard: React.FC = () => (
    <div className="bg-black/20 backdrop-blur-md border border-white/10 rounded-xl p-6 shadow-lg animate-pulse">
        <div className="flex items-center mb-4">
            <div className="w-10 h-10 bg-white/10 rounded-full mr-3"></div>
            <div className="w-1/3 h-6 bg-white/10 rounded"></div>
        </div>
        <div className="space-y-2">
            <div className="w-full h-4 bg-white/10 rounded"></div>
            <div className="w-5/6 h-4 bg-white/10 rounded"></div>
            <div className="w-3/4 h-4 bg-white/10 rounded"></div>
        </div>
    </div>
);

const Loader: React.FC = () => {
    return (
        <div className="space-y-8 mt-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <SkeletonCard />
                <SkeletonCard />
                <SkeletonCard />
                <SkeletonCard />
            </div>
        </div>
    );
};

export default Loader;
